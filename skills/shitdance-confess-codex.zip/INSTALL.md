# Shit Dance Confess for Codex

Install this package by extracting the `shitdance-confess/` folder into your Codex skills directory.

Personal install:

```bash
mkdir -p ~/.codex/skills
unzip shitdance-confess-codex.zip -d ~/.codex/skills
```

Then ask Codex: `shitdance please`.
