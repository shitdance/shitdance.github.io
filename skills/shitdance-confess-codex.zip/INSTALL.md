# Shit Dance Confess for Codex

Extract the `shitdance-confess/` folder into your Codex skills directory:

```bash
mkdir -p ~/.codex/skills
unzip shitdance-confess-codex.zip -d ~/.codex/skills
```

Then ask Codex: `shitdance please`.
