# Shit Dance Confess for Any Agent

Use `shitdance-confess/SKILL.md` as the rulebook for any agent that can read local Markdown.

```text
Read the bundled shitdance-confess/SKILL.md and follow it to turn coding-agent failures into privacy-safe Shit Dance Moments. Preserve the failure mechanics, redact sensitive details, and do not claim publication unless an actual publishing action happens after user confirmation.
```
