# Shit Dance Confess for GitHub Copilot

Extract the zip into your project, then reference the skill from
`.github/copilot-instructions.md`:

```text
When the user says "shitdance please" or asks for an Agent Confession, read shitdance-confess/SKILL.md and follow it exactly: mine the whole visible session as the incident and write only the privacy-safe guilty-agent confession essay first. Keep private paths, repo names, customer data, tokens, and internal URLs redacted.
```
