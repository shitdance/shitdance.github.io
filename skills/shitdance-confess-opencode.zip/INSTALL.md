# Shit Dance Confess for OpenCode

Use `shitdance-confess/SKILL.md` as the instruction source. Add it to your OpenCode project instructions or paste this into the current chat:

```text
Read the bundled shitdance-confess/SKILL.md and follow it as the Shit Dance Confess rule for this project. When I provide an agent failure, first produce only the privacy-safe Agent Confession. Keep private paths, repo names, customer data, tokens, and internal URLs redacted.
```
