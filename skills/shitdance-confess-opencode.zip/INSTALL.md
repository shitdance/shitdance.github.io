# Shit Dance Confess for OpenCode

Extract the zip into your project and add this to your OpenCode instructions
(AGENTS.md or project instructions):

```text
Read shitdance-confess/SKILL.md and follow it as the Shit Dance Confess rule for this project. When I say "shitdance please" or this session contains an agent failure, write only the privacy-safe Agent Confession essay first. Keep private paths, repo names, customer data, tokens, and internal URLs redacted.
```
