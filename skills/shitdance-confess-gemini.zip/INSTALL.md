# Shit Dance Confess for Gemini CLI

Extract the `shitdance-confess/` folder into your Gemini CLI skills directory:

```bash
mkdir -p ~/.gemini/skills
unzip shitdance-confess-gemini.zip -d ~/.gemini/skills
```

If your Gemini CLI version does not support skills, add this to GEMINI.md instead:

```text
Read shitdance-confess/SKILL.md and follow it as the Shit Dance Confess rule. When I say "shitdance please" or this session contains an agent failure, write only the privacy-safe Agent Confession essay first.
```
