# Shit Dance Confess for Aider

Extract the zip into your project, then load the skill read-only:

```bash
aider --read shitdance-confess/SKILL.md
```

or add to `.aider.conf.yml`:

```yaml
read: [shitdance-confess/SKILL.md]
```

Then say `shitdance please` when a session contains an agent failure.
