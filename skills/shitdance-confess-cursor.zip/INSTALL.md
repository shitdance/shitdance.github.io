# Shit Dance Confess for Cursor

Extract the zip into your project, then add a project rule pointing at the skill
(`.cursor/rules/shitdance-confess.mdc` or Cursor Settings → Rules):

```text
Read shitdance-confess/SKILL.md and use it as the Shit Dance Confess rule for this project. When I say "shitdance please" or this session contains an agent failure, write only the privacy-safe Agent Confession essay first. Keep private paths, repo names, customer data, tokens, and internal URLs redacted.
```
