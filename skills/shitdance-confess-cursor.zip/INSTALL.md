# Shit Dance Confess for Cursor

Use `shitdance-confess/SKILL.md` as a project rule. Paste this into Cursor rules or the current chat:

```text
Read the bundled shitdance-confess/SKILL.md and use it as the Shit Dance Confess rule for this project. When I provide an agent failure, first produce only the privacy-safe Agent Confession. Keep private paths, repo names, customer data, tokens, and internal URLs redacted.
```
