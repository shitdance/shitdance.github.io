# Shit Dance Confess for Claude Code

Extract the `shitdance-confess/` folder into your Claude Code skills directory:

```bash
mkdir -p ~/.claude/skills
unzip shitdance-confess-claude.zip -d ~/.claude/skills
```

Then say: `shitdance please`.

Fallback (no skills support): paste into project instructions with the folder attached:

```text
Read the bundled shitdance-confess/SKILL.md and follow it as the Shit Dance Confess writing and redaction rules for this project. When I provide an agent failure (or when this session itself contains one), produce only the privacy-safe Agent Confession essay first. Do not publish, make labels, or produce issue-ready content until I explicitly ask for it.
```
