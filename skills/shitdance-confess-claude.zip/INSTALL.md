# Shit Dance Confess for Claude

Use `shitdance-confess/SKILL.md` as the project instruction source. Paste this into Claude project instructions or the current chat:

```text
Read the bundled shitdance-confess/SKILL.md and follow it as the Shit Dance Confess writing and redaction rules for this project. When I provide an agent failure, first produce only the privacy-safe Agent Confession. Do not publish, make labels, or produce issue-ready content until I explicitly ask for it.
```
